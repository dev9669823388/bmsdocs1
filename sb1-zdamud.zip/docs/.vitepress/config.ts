import { defineConfig } from 'vitepress'

export default defineConfig({
  title: "Bot Master Sender",
  description: "WhatsApp Message Sending API Documentation",
  themeConfig: {
    nav: [
      { text: 'Home', link: '/' },
      { text: 'Guide', link: '/guide/' },
      { text: 'API Reference', link: '/api-reference/' },
      { text: 'Plans', link: '/plans/' }
    ],
    sidebar: [
      {
        text: 'Introduction',
        items: [
          { text: 'Getting Started', link: '/guide/' },
          { text: 'Authentication', link: '/guide/authentication' }
        ]
      },
      {
        text: 'API Reference',
        items: [
          { text: 'Overview', link: '/api-reference/' },
          { text: 'Send Message', link: '/api-reference/send-message' },
          { text: 'Parameters', link: '/api-reference/parameters' }
        ]
      },
      {
        text: 'Plans',
        items: [
          { text: 'Pricing Plans', link: '/plans/' }
        ]
      }
    ],
    socialLinks: [
      { icon: 'github', link: 'https://github.com/your-repo' }
    ]
  }
})